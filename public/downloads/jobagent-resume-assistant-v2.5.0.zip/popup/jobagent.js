// ============================================================
// JobAgent 网申资料包 v1：格式校验与简历助手字段映射
// ------------------------------------------------------------
// 这里只做纯数据转换，不读写 storage、不触发填写、更不会提交表单。
// 弹窗先调用 parse() 预览，用户确认后才把 map() 的结果存成一套新方案。
// ============================================================
(function () {
  const G = (typeof window !== "undefined") ? window : self;

  const DEGREE = {
    doctor: { degree: "博士研究生", degreeName: "博士" },
    master: { degree: "硕士研究生", degreeName: "硕士" },
    bachelor: { degree: "本科", degreeName: "学士" },
    associate: { degree: "大专", degreeName: "" },
    other: { degree: "其他", degreeName: "" }
  };

  function text(v) {
    return typeof v === "string" ? v.trim() : "";
  }

  function isStringArray(v) {
    return Array.isArray(v) && v.every(x => typeof x === "string");
  }

  function isEducation(v) {
    return !!v && typeof v === "object" &&
      ["doctor", "master", "bachelor", "associate", "other"].includes(v.degree) &&
      ["school", "college", "major", "periodStart", "periodEnd", "performance"]
        .every(k => typeof v[k] === "string");
  }

  function isExperience(v) {
    return !!v && typeof v === "object" &&
      ["title", "role", "periodStart", "periodEnd"].every(k => typeof v[k] === "string") &&
      isStringArray(v.bullets);
  }

  function validate(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return "JSON 顶层必须是对象";
    if (value.schema !== "jobagent-autofill-package") return "这不是 JobAgent 网申资料包";
    if (value.version !== 1) return "暂不支持这个资料包版本（当前仅支持 v1）";
    if (typeof value.packageId !== "string" || typeof value.createdAt !== "string") return "资料包缺少编号或创建时间";

    const variant = value.resumeVariant;
    if (!variant || typeof variant !== "object" ||
      !["id", "name", "directionId", "directionName"].every(k => typeof variant[k] === "string")) {
      return "资料包缺少简历版本或方向信息";
    }

    const profile = value.profile;
    const profileKeys = ["name", "email", "phone", "location", "school", "major", "degree", "graduationYear", "jobType"];
    if (!profile || typeof profile !== "object" || !profileKeys.every(k => typeof profile[k] === "string") ||
      !isStringArray(profile.cities) ||
      (profile.workAuthorization !== undefined && typeof profile.workAuthorization !== "string")) {
      return "资料包中的基本资料格式不完整";
    }

    if (!Array.isArray(value.education) || !value.education.every(isEducation)) return "教育经历格式不正确";
    if (!Array.isArray(value.experiences) || !value.experiences.every(isExperience)) return "实习/工作经历格式不正确";
    if (!Array.isArray(value.projects) || !value.projects.every(isExperience)) return "项目经历格式不正确";
    if (!["honors", "skills", "strengths"].every(k => isStringArray(value[k]))) return "荣誉、技能或优势格式不正确";
    if (!Array.isArray(value.confirmedAnswers) || !value.confirmedAnswers.every(answer =>
      answer && typeof answer === "object" && typeof answer.question === "string" && typeof answer.answer === "string")) {
      return "已确认问答格式不正确";
    }
    return "";
  }

  function parse(input) {
    let value = input;
    if (typeof input === "string") {
      try { value = JSON.parse(input); }
      catch (e) { return { ok: false, reason: "JSON 文件无法解析" }; }
    }
    const reason = validate(value);
    return reason ? { ok: false, reason } : { ok: true, package: value };
  }

  function joinLines(items) {
    return (items || []).map(text).filter(Boolean).join("\n");
  }

  function experienceLine(item) {
    const heading = [text(item.title), text(item.role)].filter(Boolean).join(" · ");
    const period = [text(item.periodStart), text(item.periodEnd)].filter(Boolean).join(" - ");
    return [heading, period, joinLines(item.bullets)].filter(Boolean).join("\n");
  }

  function mapPerformance(value) {
    const v = text(value);
    if (!v) return { gpa: "", ranking: "" };
    const hasGpa = /gpa|绩点/i.test(v);
    const hasRanking = /排名|前\s*\d+(?:\.\d+)?\s*%/i.test(v);
    return {
      // 两类信息混在一句里时保留原文，避免截断数值或误拆语义。
      gpa: hasGpa ? v : "",
      ranking: hasRanking ? v : ""
    };
  }

  function degreeFromEntry(entry) {
    return DEGREE[entry.degree] || DEGREE.other;
  }

  function normalizeJobType(value) {
    const v = text(value);
    if (/实习/.test(v)) return "实习";
    if (/社招|社会招聘/.test(v)) return "社招";
    if (/校招|校园招聘|应届/.test(v)) return "校园招聘";
    return v;
  }

  function makeCustomFields(pkg) {
    const out = [];
    const seen = new Set();
    function add(label, value) {
      const l = text(label), v = text(value);
      if (!l || !v || seen.has(l)) return;
      seen.add(l);
      out.push({ label: l, value: v });
    }
    if (pkg.profile.workAuthorization) add("工作许可 / 签证情况", pkg.profile.workAuthorization);
    pkg.confirmedAnswers.forEach(item => add(item.question, item.answer));
    return out;
  }

  function mapPackage(pkg) {
    const education = pkg.education.map(item => {
      const degree = degreeFromEntry(item);
      const performance = mapPerformance(item.performance);
      return {
        school: text(item.school),
        study_mode: "",
        major: text(item.major),
        degree: degree.degree,
        degree_name: degree.degreeName,
        college: text(item.college),
        start: text(item.periodStart),
        end: text(item.periodEnd),
        gpa: performance.gpa,
        ranking: performance.ranking
      };
    });

    const internships = pkg.experiences.map(item => ({
      company: text(item.title),
      position: text(item.role),
      start: text(item.periodStart),
      end: text(item.periodEnd),
      desc: joinLines(item.bullets)
    }));

    const projects = pkg.projects.map(item => ({
      name: text(item.title),
      role: text(item.role),
      start: text(item.periodStart),
      end: text(item.periodEnd),
      desc: joinLines(item.bullets)
    }));

    const firstEducation = education[0] || {};
    const profile = pkg.profile;
    const resumeData = {
      name: text(profile.name),
      email: text(profile.email),
      phone: text(profile.phone),
      current_residence: text(profile.location),
      school: text(profile.school) || firstEducation.school || "",
      major: text(profile.major) || firstEducation.major || "",
      degree: text(profile.degree) || firstEducation.degree || "",
      degree_name: firstEducation.degree_name || "",
      graduate_year: text(profile.graduationYear),
      college: firstEducation.college || "",
      education_period: firstEducation.start && firstEducation.end
        ? firstEducation.start + " - " + firstEducation.end : "",
      gpa: firstEducation.gpa || "",
      grade_ranking: firstEducation.ranking || "",
      city: text(profile.cities[0]),
      // 方向不等于具体岗位名称，所以这里有意不填写 position。
      position: "",
      job_type: normalizeJobType(profile.jobType),
      intro: joinLines(pkg.strengths),
      skills: joinLines(pkg.skills),
      awards: joinLines(pkg.honors),
      education: education.map(item => [
        [item.school, item.college].filter(Boolean).join(" · "),
        [item.degree, item.major].filter(Boolean).join(" · "),
        [item.start, item.end].filter(Boolean).join(" - "),
        [item.gpa, item.ranking].filter(Boolean).join("；")
      ].filter(Boolean).join("\n")).join("\n\n"),
      internship: pkg.experiences.map(experienceLine).join("\n\n"),
      work: "",
      project: pkg.projects.map(experienceLine).join("\n\n")
    };

    const warnings = [];
    if (pkg.experiences.length) warnings.push("资料包没有区分实习与正式工作，已先放入“实习经历”，请导入后复核。 ");
    if (!profile.email || !profile.phone) warnings.push("邮箱或手机号不完整，请导入后补充。 ");
    if (pkg.resumeVariant.directionName) warnings.push("方向仅用于方案命名，不会当作具体应聘岗位填写。 ");

    return {
      resumeData,
      blocks: { education, internship: internships, project: projects, work: [], family: [] },
      customFields: makeCustomFields(pkg),
      meta: {
        schema: pkg.schema,
        version: pkg.version,
        packageId: pkg.packageId,
        createdAt: pkg.createdAt,
        resumeVariantId: pkg.resumeVariant.id,
        directionId: pkg.resumeVariant.directionId,
        importedAt: new Date().toISOString()
      },
      summary: {
        profileName: text(pkg.resumeVariant.name) || "JobAgent 简历",
        directionName: text(pkg.resumeVariant.directionName) || "待分类",
        educationCount: education.length,
        experienceCount: internships.length,
        projectCount: projects.length,
        answerCount: pkg.confirmedAnswers.length,
        contactCount: [profile.name, profile.email, profile.phone].filter(x => text(x)).length,
        warnings
      }
    };
  }

  G.JIANLI_JOBAGENT = { parse, validate, map: mapPackage, mapPerformance };
})();
